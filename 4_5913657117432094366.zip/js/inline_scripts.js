
{"@context":"https://schema.org","@graph":[
  {"@type":"WebApplication","name":"AHM7xMakki Universal Video Downloader","url":"https://ahm7xmakki.com/alldl","description":"Free video downloader for YouTube, TikTok without watermark, Instagram, Facebook, Twitter/X, Reddit, CapCut, SnackVideo, Snapchat, SoundCloud, Douyin.","applicationCategory":"UtilitiesApplication","operatingSystem":"Any","offers":{"@type":"Offer","price":"0","priceCurrency":"USD"},"featureList":["YouTube MP4 download","TikTok no watermark","Instagram Reels","Facebook video","Twitter/X video","Reddit with audio","CapCut no watermark","Free REST API","No signup"]},
  {"@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https://ahm7xmakki.com/"},{"@type":"ListItem","position":2,"name":"Video Downloader","item":"https://ahm7xmakki.com/alldl"}]},
  {"@type":"FAQPage","mainEntity":[
    {"@type":"Question","name":"How do I download TikTok videos without watermark?","acceptedAnswer":{"@type":"Answer","text":"Paste your TikTok URL into the box above and click Download. AHM7xMakki automatically removes the TikTok watermark and returns a clean MP4 instantly — free, no signup."}},
    {"@type":"Question","name":"How do I download YouTube videos for free?","acceptedAnswer":{"@type":"Answer","text":"Copy any YouTube URL, paste it in the input above, click Download. You get a direct MP4 link instantly with no software install needed."}},
    {"@type":"Question","name":"Which platforms are supported?","acceptedAnswer":{"@type":"Answer","text":"YouTube, TikTok (no watermark), Instagram Reels, Facebook, Twitter/X, Reddit (with audio), Snapchat, SoundCloud, Douyin, SnackVideo, and CapCut — 11 platforms total."}},
    {"@type":"Question","name":"Is this video downloader free?","acceptedAnswer":{"@type":"Answer","text":"Yes — 100% free. No signup, no watermark on output, no software install, no limits for fair use."}},
    {"@type":"Question","name":"Does it work on mobile?","acceptedAnswer":{"@type":"Answer","text":"Yes. Works on any browser on iPhone, Android, and desktop. No app download required."}},
    {"@type":"Question","name":"Is there a free video downloader API?","acceptedAnswer":{"@type":"Answer","text":"Yes. Use GET /api/alldl?url=VIDEO_URL — no API key required. See the API docs section on this page."}},
    {"@type":"Question","name":"Why does Reddit video have no sound?","acceptedAnswer":{"@type":"Answer","text":"Reddit stores video and audio separately. Our tool merges them automatically so you get a single MP4 with full audio."}},
    {"@type":"Question","name":"Can I download Instagram Reels for free?","acceptedAnswer":{"@type":"Answer","text":"Yes. Paste any public Instagram Reel URL and download as MP4. Private accounts are not supported."}}
  ]}
]}


/* ===== INLINE JAVASCRIPT ===== */


const API = window.location.origin + '/api/alldl';
let busy = false;

const urlInput   = document.getElementById('urlInput');
const dlBtn      = document.getElementById('dlBtn');
const btnTxt     = document.getElementById('btnTxt');
const spinnerWrap= document.getElementById('spinnerWrap');
const resultsBox = document.getElementById('resultsBox');
const mediaContent=document.getElementById('mediaContent');
const msgErr     = document.getElementById('msgErr');
const msgOk      = document.getElementById('msgOk');
const msgInfo    = document.getElementById('msgInfo');

const PLATFORMS = ['youtube.com','youtu.be','tiktok.com','vm.tiktok.com','vt.tiktok.com','instagram.com','instagr.am','facebook.com','fb.com','fb.watch','twitter.com','x.com','t.co','reddit.com','redd.it','snapchat.com','soundcloud.com','douyin.com','v.douyin.com','snackvideo.com','s.snackvideo.com','capcut.com'];

function validURL(u){
  try{ const h=new URL(u).hostname; return PLATFORMS.some(p=>h.includes(p)); }
  catch{ return false; }
}

function showMsg(el, txt){ hideAllMsgs(); el.textContent=txt; el.style.display='block'; }
function hideAllMsgs(){ [msgErr,msgOk,msgInfo].forEach(e=>{e.style.display='none'; e.textContent='';}); }

function setLoading(on){
  spinnerWrap.style.display = on ? 'block' : 'none';
  dlBtn.disabled = on;
  btnTxt.textContent = on ? 'Processing...' : '⬇ Download';
  if(on){ resultsBox.style.display='none'; hideAllMsgs(); }
}

function esc(s){ return s ? s.replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])) : ''; }

function buildResults(info){
  let html = '';

  // Title + platform
  if(info.title) html += `<div class="media-title">🎬 ${esc(info.title)}</div>`;
  if(info.platform) html += `<div class="media-platform">Platform: ${esc(info.platform)}</div>`;

  // Media preview
  const isSoundCloud = info.platform === 'SoundCloud';
  if(!isSoundCloud && info.videoUrl){
    html += `<video class="media-video" controls preload="metadata" playsinline>
      <source src="${info.videoUrl}" type="video/mp4">
      Your browser does not support video playback.
    </video>`;
  } else if(isSoundCloud && (info.audioUrl || info.downloadMp3)){
    const au = info.audioUrl || info.downloadMp3;
    html += `<audio class="media-audio" controls preload="metadata">
      <source src="${au}" type="audio/mpeg">
    </audio>`;
  } else if(info.thumbnail || info.coverImage){
    const img = info.thumbnail || info.coverImage;
    html += `<img class="media-thumb" src="${esc(img)}" alt="Video thumbnail"/>`;
  }

  // Download buttons
  html += '<div class="dl-buttons">';

  if(info.videoUrl && !isSoundCloud)
    html += `<a href="${esc(info.videoUrl)}" class="dl-btn-link" target="_blank" rel="noopener">📹 Download Video</a>`;

  if(info.audioUrl)
    html += `<a href="${esc(info.audioUrl)}" class="dl-btn-link dl-btn-secondary" target="_blank" rel="noopener">🎵 Download Audio</a>`;

  if(info.downloadMp3 && !info.audioUrl)
    html += `<a href="${esc(info.downloadMp3)}" class="dl-btn-link dl-btn-secondary" target="_blank" rel="noopener">🎵 Download MP3</a>`;

  if(info.musicUrl)
    html += `<a href="${esc(info.musicUrl)}" class="dl-btn-link dl-btn-secondary" target="_blank" rel="noopener">🎶 Background Music</a>`;

  // Quality options (Twitter, Douyin, Reddit etc.)
  if(info.qualities && info.qualities.length){
    info.qualities.slice(0,5).forEach(q=>{
      if(q.url && q.quality && q.quality !== 'MP3'){
        html += `<a href="${esc(q.url)}" class="dl-btn-link" target="_blank" rel="noopener">📱 ${esc(q.quality)}</a>`;
      }
    });
  }

  html += '</div>';
  return html;
}

async function handleDownload(){
  const url = urlInput.value.trim();
  if(!url){ showMsg(msgErr,'Please paste a video URL first.'); return; }
  if(!validURL(url)){ showMsg(msgErr,'URL not recognised. Supported: YouTube, TikTok, Instagram, Facebook, Twitter, Reddit, Snapchat, SoundCloud, CapCut, SnackVideo, Douyin.'); return; }
  if(busy) return;
  busy = true;
  setLoading(true);

  try{
    const res  = await fetch(`${API}?url=${encodeURIComponent(url)}`);
    const data = await res.json();

    if(data.success && data.mediaInfo){
      mediaContent.innerHTML = buildResults(data.mediaInfo);
      resultsBox.style.display = 'block';
      showMsg(msgOk, '✅ Download ready — use the buttons below to save your file.');
      resultsBox.scrollIntoView({behavior:'smooth', block:'nearest'});
    } else {
      const errMsg = data.message || 'Could not process this URL. Please try again.';
      showMsg(msgErr, errMsg);
    }
  } catch(e){
    showMsg(msgErr, 'Network error — please check your connection and try again.');
  } finally {
    setLoading(false);
    busy = false;
  }
}

dlBtn.addEventListener('click', handleDownload);
urlInput.addEventListener('keydown', e => { if(e.key==='Enter') handleDownload(); });
urlInput.addEventListener('input', ()=>{
  const v = urlInput.value.trim();
  urlInput.classList.toggle('err', v.length > 10 && !validURL(v));
});

function copyCode(btn){
  const pre = btn.closest('.code-wrap').querySelector('.code-body');
  navigator.clipboard.writeText(pre.innerText);
  btn.textContent='copied!';
  setTimeout(()=>btn.textContent='copy', 1500);
}

// Scroll reveal
const obs = new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('vis'); });
},{threshold:0.07});
document.querySelectorAll('.fade').forEach(el=>obs.observe(el));
